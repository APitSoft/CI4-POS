<?php

namespace App\Controllers;

class Kasbank extends BaseController
{
    public function penerimaan()
    {
        $css = [];
        $js = [];
        $data  = [
            'css' => $css,
            'js' => $js,
            'title' => 'e-Abiyosoft &#8482;',
            'body' => 'admin/kas_bank/transaksi/penerimaan',
        ];
        return view('layout/layout', $data);
    }

    public function penerimaan_entri()
    {
        $css = [];
        $js = [];
        $data  = [
            'css' => $css,
            'js' => $js,
            'title' => 'e-Abiyosoft &#8482;',
            'body' => 'admin/kas_bank/transaksi/penerimaan_entri',
        ];
        return view('layout/layout', $data);
    }
    public function transfer_entri()
    {
        $css = [];
        $js = [];
        $data  = [
            'css' => $css,
            'js' => $js,
            'title' => 'e-Abiyosoft &#8482;',
            'body' => 'admin/kas_bank/transaksi/transfer_bank_entri',
        ];
        return view('layout/layout', $data);
    }
    public function pembayaran_entri()
    {
        $css = [];
        $js = [];
        $data  = [
            'css' => $css,
            'js' => $js,
            'title' => 'e-Abiyosoft &#8482;',
            'body' => 'admin/kas_bank/transaksi/pembayaran_entri',
        ];
        return view('layout/layout', $data);
    }

    public function pembayaran()
    {
        $css = [];
        $js = [];
        $data  = [
            'css' => $css,
            'js' => $js,
            'title' => 'e-Abiyosoft &#8482;',
            'body' => 'admin/kas_bank/transaksi/pembayaran',
        ];
        return view('layout/layout', $data);
    }

    public function transfer_bank()
    {
        $css = [];
        $js = [];
        $data  = [
            'css' => $css,
            'js' => $js,
            'title' => 'e-Abiyosoft &#8482;',
            'body' => 'admin/kas_bank/transaksi/transfer_bank',
        ];
        return view('layout/layout', $data);
    }

    public function laporan()
    {
        $css = [];
        $js = [];
        $data  = [
            'css' => $css,
            'js' => $js,
            'title' => 'e-Abiyosoft &#8482;',
            'body' => 'admin/kas_bank/laporan',
        ];
        return view('layout/layout', $data);
    }
}
