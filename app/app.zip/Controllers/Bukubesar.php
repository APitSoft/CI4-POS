<?php

namespace App\Controllers;

class Bukubesar extends BaseController
{
    public function kode_akun()
    {
        $css = [];
        $js = [];
        $data  = [
            'css' => $css,
            'js' => $js,
            'title' => 'e-Abiyosoft &#8482;',
            'body' => 'admin/buku_besar/data_master/kode_akun',
        ];
        return view('layout/layout', $data);
    }

    public function saldo_awal_akun()
    {
        $css = [];
        $js = [];
        $data  = [
            'css' => $css,
            'js' => $js,
            'title' => 'e-Abiyosoft &#8482;',
            'body' => 'admin/buku_besar/data_master/saldo_awal_akun',
        ];
        return view('layout/layout', $data);
    }

    public function entri_jurnal()
    {
        $css = [];
        $js = [];
        $data  = [
            'css' => $css,
            'js' => $js,
            'title' => 'e-Abiyosoft &#8482;',
            'body' => 'admin/buku_besar/transaksi/entri_jurnal',
        ];
        return view('layout/layout', $data);
    }

    public function daftar_jurnal()
    {
        $css = [];
        $js = [];
        $data  = [
            'css' => $css,
            'js' => $js,
            'title' => 'e-Abiyosoft &#8482;',
            'body' => 'admin/buku_besar/transaksi/daftar_jurnal',
        ];
        return view('layout/layout', $data);
    }

    public function daftar_jurnal_entri()
    {
        $css = [];
        $js = [];
        $data  = [
            'css' => $css,
            'js' => $js,
            'title' => 'e-Abiyosoft &#8482;',
            'body' => 'admin/buku_besar/transaksi/daftar_jurnal_entri',
        ];
        return view('layout/layout', $data);
    }

    public function tutup_buku()
    {
        $css = [];
        $js = [];
        $data  = [
            'css' => $css,
            'js' => $js,
            'title' => 'e-Abiyosoft &#8482;',
            'body' => 'admin/buku_besar/transaksi/tutup_buku',
        ];
        return view('layout/layout', $data);
    }

    public function laporan()
    {
        $css = [];
        $js = [];
        $data  = [
            'css' => $css,
            'js' => $js,
            'title' => 'e-Abiyosoft &#8482;',
            'body' => 'admin/buku_besar/laporan',
        ];
        return view('layout/layout', $data);
    }
}
