<div class="container-fluid">
    <?= main_header('Buku Besar', 'Akun Perkiraan') ?>
    <?= main_periode('Daftar Akun Perkiraan', 0) ?>
    <?= main_button('Data Baru', 1, 1, '', 'tambahDataModal') ?>

    <table id="table" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th style="text-align: center">Kode Perkiraan</th>
                <th style="text-align: center">Nama</th>
                <th style="text-align: center">Tipe Akun</th>
                <th style="text-align: center">Transaksi</th>
                <th style="text-align: center;width:16%;">&nbsp;</th>

            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
</div>

<!-- Bootstrap modal -->
<div class="modal fade" id="tambahDataModal" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Data Akun</h3>
                <button type="button" class="btn" data-bs-dismiss="modal" aria-label="Close"><span aria-hidden="true"><i class="fa-solid fa-close"></i></span></button>
            </div>
            <div class="modal-body form">
                <form action="#" id="form" class="form-horizontal">
                    <input type="hidden" value="0" name="id" />
                    <div class="form-body">
                        <div class="form-group mb-3">
                            <div class="row">
                                <label class="control-label col-md-3">Kode Akun</label>
                                <div class="col-md-9">
                                    <input name="kodeakun" placeholder="Kode Akun" class="form-control" type="text">
                                    <span class="help-block"></span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group mb-3">
                            <div class="row">
                                <label class="control-label col-md-3">Nama Akun</label>
                                <div class="col-md-9">
                                    <input name="namaakun" placeholder="Nama Akun" class="form-control" type="text">
                                    <span class="help-block"></span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group mb-3">
                            <div class="row">
                                <label class="control-label col-md-3">Tipe Akun</label>
                                <div class="col-md-9">
                                    <select id="jenis" name="jenis" class="form-control input-mediumx select2me" data-placeholder="Pilih..." required>
                                        <option value="BANK">Kas & Bank</option>
                                        <option value="AREC">Piutang Usaha</option>
                                        <option value="INTR">Persediaan</option>
                                        <option value="OCAS">Aset Lancar Lainnya</option>
                                        <option value="FASS">Aset Tetap</option>
                                    </select>
                                    <span class="jenisErr"></span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group mb-3">
                            <div class="row">
                                <label class="control-label col-md-3">Akun Induk</label>
                                <div class="col-md-9">
                                    <select id="akuninduk" name="akuninduk" class="form-control input-mediumx select2me" data-placeholder="Pilih..." required>
                                        <option value="">&nbsp;</option>
                                        <option value="1101">1101 - Kas & Bank</option>
                                        <option value="110101">110101 - Kas Kecil</option>
                                        <option value="110102">110102 - Bank</option>
                                        <option value="110103">110103 - Bank BJB</option>
                                    </select>
                                    <span class="help-block"></span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group mb-3">
                            <div class="row">
                                <label class="control-label col-md-3">Kode Penerimaan</label>
                                <div class="col-md-9">
                                    <input name="kodem" placeholder="Kode Bukti Penerimaan" class="form-control" type="text" maxlength="10">
                                    <span class="help-block"></span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group mb-3">
                            <div class="row">
                                <label class="control-label col-md-3">Kode Pengeluaran</label>
                                <div class="col-md-9">
                                    <input name="kodek" placeholder="Kode Bukti Penerimaan" class="form-control" type="text" maxlength="10">
                                    <span class="help-block"></span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group mb-3">
                            <div class="row">
                                <label class="control-label col-md-3">Akun Transaksi</label>
                                <div class="col-md-9">
                                    <select id="akuntx" name="akuntx" class="form-control input-mediumx select2me" data-placeholder="Pilih..." required>
                                        <option value="">&nbsp;</option>
                                        <option value="Y">Ya</option>
                                        <option value="T">Tidak</option>
                                    </select>
                                    <span class="help-block"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" id="btnSave" class="btn btn-primary">Simpan</button>
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Batal</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<script>
    $(document).ready(function() {
        $('#table').DataTable();
    });
</script>