<div class="container fluid">
    <?= main_header('Buku Besar', 'Saldo Awal Perkiraan') ?>
    <?= main_periode('Daftar Saldo Awal Akun Perkiraan', 0) ?>
    <?= main_button('Data Baru', 1, 1, '', 'tambahDataModal') ?>


    <table id="table" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th style="text-align: center; width:10%">Kode Perkiraan</th>
                <th style="text-align: center; width:44%">Nama</th>
                <th style="text-align: center; width:15%">Debet</th>
                <th style="text-align: center; width:15%">Kredit</th>
                <th style="text-align: center;width:20%;">&nbsp</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="2">Total</td>
                <td>Debet</td>
                <td>Kredit</td>
                <td></td>
            </tr>
        </tfoot>
    </table>
</div>

<!-- Bootstrap modal -->
<div class="modal fade" id="tambahDataModal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Data Akun</h3>
                <button type="button" class="btn" data-bs-dismiss="modal" aria-label="Close"><span aria-hidden="true"><i class="fa-solid fa-close"></i></span></button>
            </div>
            <div class="modal-body form">
                <form action="#" id="form" class="form-horizontal">
                    <input type="hidden" value="0" name="id" />
                    <div class="form-body">
                        <div class="form-group mb-3">
                            <div class="row">
                                <label class="control-label col-md-3">Kode Akun</label>
                                <div class="col-md-9">
                                    <select id="kodeakun" name="kodeakun" class="form-select input-mediumx select2me" data-placeholder="Pilih..." required>
                                        <option value="110101">110101 - Kas Kecil</option>
                                        <option value="110102">110102 - Bank</option>
                                        <option value="110103">110103 - Bank BJB</option>
                                        <option value="110104">110104 - New Account</option>
                                    </select>
                                    <span class="help-block"></span>
                                </div>
                            </div>
                        </div>

                        <div class="form-group mb-3">
                            <div class="row">
                                <label class="control-label col-md-3">Debet</label>
                                <div class="col-md-9">
                                    <input name="debet" placeholder="Debet" class="form-control input-medium" type="text" value="0">
                                    <span class="help-block"></span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group mb-3">
                            <div class="row">
                                <label class="control-label col-md-3">Kredit</label>
                                <div class="col-md-9">
                                    <input name="kredit" placeholder="Kredit" class="form-control input-medium" type="text" value="0">
                                    <span class="help-block"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" id="btnSave" class="btn btn-primary">Simpan</button>
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Batal</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<script>
    $(document).ready(function() {
        $('#table').DataTable({});
    });
</script>