<div class="container-fluid">
    <?= main_header('Keuangan', 'Daftar Transfer Kas/Bank', 'Keuangan', 'Data Transfer Kas/Bank') ?>
    <?= main_periode('Daftar Transfer Kas/Bank') ?>
    <?= main_button('Data Baru', 0, 1, 'kasbank/transaksi/transfer_bank/entri') ?>

    <div class="datatable-example">
        <table class="table table-striped table-hover table-bordered" id="table">
            <thead>
                <tr>
                    <th style="text-align: center">Nomor</th>
                    <th style="text-align: center">Tanggal</th>
                    <th style="text-align: center">Bank (Keluar)</th>
                    <th style="text-align: center">Bank (Masuk)</th>
                    <th style="text-align: center">Keterangan</th>
                    <th style="text-align: center">Total</th>
                    <th>&nbsp</th>
                    <th>&nbsp</th>
                    <th>&nbsp</th>
                </tr>
            </thead>


            <tbody>

               

                

                <tr class="show1" id="row_BM2023.05.0001">
                    <td align="center">BM2023.05.0001</td>
                    <td align="center">02-05-2023</td>
                    <td align="center">02-05-2023</td>
                    <td>Penerimaan ST.2023.05.000015</td>
                    <td align="right">
                        13,229,776 </td>

                    <td style="text-align: center"> 2,126,54


                    </td>

                    <td style="text-align: center">


                        <a href="https://ajf.sistemkesehatan.id/keuangan_masuk/edit/1622">Edit</a>
                    </td>
                    </td>
                    <td style="text-align: center">
                        <a class="delete" href="javascript:">Hapus</a>
                    </td>
                    <td style="text-align: center">

                        <a class="print_laporan" id="1622" href="#report" data-toggle="modal">Cetak</a>
                    </td>
                </tr>


            </tbody>
            <tfoot>

                <td colspan="5" style="text-align:right">Total:</td>
                <td style="text-align:center">86,446</td>
                <td colspan="3"></td>


            </tfoot>

        </table>
    </div>
</div>


<script>
    $(document).ready(function() {
        $('#table').DataTable({});
    });
</script>