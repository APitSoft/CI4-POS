 <footer class="footer">
     <div class="container-fluid">
         <div class="footer-inner">
             e-Abiyosoft - <script>
                 document.write(new Date().getFullYear())
             </script> &copy; e-Soft™| Periode : 4-2023 |Senin, 17 April 2023 <span id="jam" style="font-size: 18px;"></span>
         </div>
     </div>
 </footer>